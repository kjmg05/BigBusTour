﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormAsiento : Form
    {
        public FormAsiento()
        {
            InitializeComponent();
        }

        AutoBus bus = new AutoBus();
        int i = 0;

        private void FormAsiento_Load(object sender, EventArgs e)
        {
            lblPlaca.Text = bus.Placa;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            i++;
            bus.Num = txtNum.Text;
            bus.Estado = "Libre";
            bus.InsertarAsiento();
            
            DialogResult result = MessageBox.Show("Asiento ingresado con éxito.", "BIG BUS TOUR", MessageBoxButtons.OK);
            if(result == DialogResult.OK)
            {
                txtNum.Clear();
                txtNum.Focus();
            }
           
            if(i == bus.Capacidad)
            {
                btnCerrar.Enabled = true;
                btnGuardar.Enabled = false;
                txtNum.Enabled = false;
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormAsiento_FormClosed(object sender, FormClosedEventArgs e)
        {
            bus.Connection.Close();
        }
    }
}
