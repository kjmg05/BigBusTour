﻿namespace ProyectoFinal
{
    partial class FormDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.RptReservacionesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.RptDataSet = new ProyectoFinal.RptDataSet();
            this.RptViajesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.RptReservacionesTableAdapter = new ProyectoFinal.RptDataSetTableAdapters.RptReservacionesTableAdapter();
            this.RptViajesTableAdapter = new ProyectoFinal.RptDataSetTableAdapters.RptViajesTableAdapter();
            this.btnOk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.RptReservacionesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RptDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RptViajesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // RptReservacionesBindingSource
            // 
            this.RptReservacionesBindingSource.DataMember = "RptReservaciones";
            this.RptReservacionesBindingSource.DataSource = this.RptDataSet;
            // 
            // RptDataSet
            // 
            this.RptDataSet.DataSetName = "RptDataSet";
            this.RptDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // RptViajesBindingSource
            // 
            this.RptViajesBindingSource.DataMember = "RptViajes";
            this.RptViajesBindingSource.DataSource = this.RptDataSet;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "Reservaciones";
            reportDataSource1.Value = this.RptReservacionesBindingSource;
            reportDataSource2.Name = "Viajes";
            reportDataSource2.Value = this.RptViajesBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "ProyectoFinal.RptViajesReservaciones.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1463, 761);
            this.reportViewer1.TabIndex = 0;
            // 
            // RptReservacionesTableAdapter
            // 
            this.RptReservacionesTableAdapter.ClearBeforeFill = true;
            // 
            // RptViajesTableAdapter
            // 
            this.RptViajesTableAdapter.ClearBeforeFill = true;
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))));
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.FlatAppearance.BorderSize = 0;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.Location = new System.Drawing.Point(1216, 704);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(235, 45);
            this.btnOk.TabIndex = 34;
            this.btnOk.Text = "CONSULTAR CLIENTES FRECUENTES";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // FormDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1463, 761);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormDash";
            this.Text = "FormDash";
            this.Load += new System.EventHandler(this.FormDash_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RptReservacionesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RptDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RptViajesBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource RptReservacionesBindingSource;
        private RptDataSet RptDataSet;
        private System.Windows.Forms.BindingSource RptViajesBindingSource;
        private RptDataSetTableAdapters.RptReservacionesTableAdapter RptReservacionesTableAdapter;
        private RptDataSetTableAdapters.RptViajesTableAdapter RptViajesTableAdapter;
        private System.Windows.Forms.Button btnOk;
    }
}