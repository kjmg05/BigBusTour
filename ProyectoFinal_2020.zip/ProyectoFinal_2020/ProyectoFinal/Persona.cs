﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public class Persona
    {
        private static string id;
        private string nombre;
        private string telefono;
        private DateTime fecha;
        private SqlConnection connection = new SqlConnection("Data Source=localhost;Initial Catalog=buses;Integrated Security=True");

        public string Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public SqlConnection Connection { get => connection; set => connection = value; }

        public void InsertarPersona()
        {
        }

        public void CargaDatos(string comando, DataGridView dgv)
        {
            Connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(comando, Connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgv.DataSource = table;
            Connection.Close();
        }
    }
}
