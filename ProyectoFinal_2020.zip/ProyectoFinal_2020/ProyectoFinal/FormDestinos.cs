﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProyectoFinal
{
    public partial class FormDestinos : Form
    {
        public FormDestinos()
        {
            InitializeComponent();
        }

        SqlCommand cmd = new SqlCommand();
        ConecctionSql conexion = new ConecctionSql();

        private void FormDestinos_Load(object sender, EventArgs e)
        {
            conexion.abrir();
            conexion.CargarDatosdeDestino(dgvDestinos);
            btnActualizar.Visible = false;
            btnEliminar.Visible = false;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDestino.Text == " " || txtCosto.Text == " ")
                {
                    MessageBox.Show("No se pueden ingresar datos en blanco", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    cmd = new SqlCommand("insert into Destinos (Nombre, Costo) Values ('" + txtDestino.Text + "', " + txtCosto.Text + ")", conexion.sc);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Registro Ingresado Correctamente!", "Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conexion.CargarDatosdeDestino(dgvDestinos);
                    txtDestino.Text = " ";
                    txtCosto.Text = " ";
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error al Ingresar el registro!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnmostrar_Click(object sender, EventArgs e)
        {
            btnActualizar.Visible = true;
            btnEliminar.Visible = true;
            btnAgregar.Visible = false;
            txtDestino.Text = dgvDestinos.CurrentRow.Cells[1].Value.ToString();
            txtCosto.Text = dgvDestinos.CurrentRow.Cells[2].Value.ToString();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            int indice, cod;
            indice = dgvDestinos.CurrentRow.Index;

            try
            {
                cod = Convert.ToInt32(dgvDestinos[0, indice].Value);
                dgvDestinos[1, indice].Value = txtDestino.Text;
                dgvDestinos[2, indice].Value = txtCosto.Text;
                cmd = new SqlCommand("update Destinos set Nombre = '" + txtDestino.Text + "', Costo = " + txtCosto.Text + " where id_destino =" + cod, conexion.sc);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registro Actualizado Correctamente!", "Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conexion.CargarDatosdeDestino(dgvDestinos);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error al Actualizar el Registro", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            txtDestino.Text = " ";
            txtCosto.Text = " ";

            btnAgregar.Visible = true;
            btnActualizar.Visible = false;
            btnEliminar.Visible = false;

        }

        private void FormDestinos_FormClosed(object sender, FormClosedEventArgs e)
        {
            conexion.cerrar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int indice, cod;

            indice = dgvDestinos.CurrentRow.Index;

            try
            {
                cod = Convert.ToInt32(dgvDestinos[0, indice].Value);

                cmd = new SqlCommand("delete from Destinos where id_destino =" + cod, conexion.sc);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registro Eliminado Correctamente!", "Eliminacion de Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conexion.CargarDatosdeDestino(dgvDestinos);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error al Eliminar el Registro!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            btnAgregar.Visible = true;
            btnActualizar.Visible = false;
            btnEliminar.Visible = false;
        }
    }
}
