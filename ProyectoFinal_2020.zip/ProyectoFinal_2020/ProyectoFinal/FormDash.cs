﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormDash : Form
    {
        public FormDash()
        {
            InitializeComponent();
        }

        private void FormDash_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'RptDataSet.RptReservaciones' table. You can move, or remove it, as needed.
            this.RptReservacionesTableAdapter.Fill(this.RptDataSet.RptReservaciones);
            // TODO: This line of code loads data into the 'RptDataSet.RptViajes' table. You can move, or remove it, as needed.
            this.RptViajesTableAdapter.Fill(this.RptDataSet.RptViajes);

            this.reportViewer1.RefreshReport();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            FormClienteFrecuente clienteFrecuente = new FormClienteFrecuente();
            clienteFrecuente.ShowDialog();
        }
    }
}
