﻿namespace ProyectoFinal
{
    partial class FormFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource6 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.ImprimirDetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.busesDataSet = new ProyectoFinal.busesDataSet();
            this.ImprimirReservacionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ImprimirFactBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblIsv = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnFactura = new System.Windows.Forms.Button();
            this.dtpFact = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.ImprimirDetTableAdapter = new ProyectoFinal.busesDataSetTableAdapters.ImprimirDetTableAdapter();
            this.ImprimirReservacionTableAdapter = new ProyectoFinal.busesDataSetTableAdapters.ImprimirReservacionTableAdapter();
            this.ImprimirFactTableAdapter = new ProyectoFinal.busesDataSetTableAdapters.ImprimirFactTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirDetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.busesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirReservacionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirFactBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // ImprimirDetBindingSource
            // 
            this.ImprimirDetBindingSource.DataMember = "ImprimirDet";
            this.ImprimirDetBindingSource.DataSource = this.busesDataSet;
            // 
            // busesDataSet
            // 
            this.busesDataSet.DataSetName = "busesDataSet";
            this.busesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ImprimirReservacionBindingSource
            // 
            this.ImprimirReservacionBindingSource.DataMember = "ImprimirReservacion";
            this.ImprimirReservacionBindingSource.DataSource = this.busesDataSet;
            // 
            // ImprimirFactBindingSource
            // 
            this.ImprimirFactBindingSource.DataMember = "ImprimirFact";
            this.ImprimirFactBindingSource.DataSource = this.busesDataSet;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.White;
            this.lblTotal.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblTotal.Location = new System.Drawing.Point(417, 621);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(16, 19);
            this.lblTotal.TabIndex = 56;
            this.lblTotal.Text = "-";
            this.lblTotal.Visible = false;
            // 
            // lblIsv
            // 
            this.lblIsv.AutoSize = true;
            this.lblIsv.BackColor = System.Drawing.Color.White;
            this.lblIsv.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsv.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblIsv.Location = new System.Drawing.Point(417, 591);
            this.lblIsv.Name = "lblIsv";
            this.lblIsv.Size = new System.Drawing.Size(16, 19);
            this.lblIsv.TabIndex = 55;
            this.lblIsv.Text = "-";
            this.lblIsv.Visible = false;
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.BackColor = System.Drawing.Color.White;
            this.lblDesc.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblDesc.Location = new System.Drawing.Point(417, 561);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(16, 19);
            this.lblDesc.TabIndex = 54;
            this.lblDesc.Text = "-";
            this.lblDesc.Visible = false;
            // 
            // lblSub
            // 
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.White;
            this.lblSub.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblSub.Location = new System.Drawing.Point(417, 531);
            this.lblSub.Name = "lblSub";
            this.lblSub.Size = new System.Drawing.Size(16, 19);
            this.lblSub.TabIndex = 53;
            this.lblSub.Text = "-";
            this.lblSub.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label4.Location = new System.Drawing.Point(163, 561);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(215, 19);
            this.label4.TabIndex = 52;
            this.label4.Text = "Descuento Tercera Edad:";
            this.label4.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label2.Location = new System.Drawing.Point(163, 591);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 19);
            this.label2.TabIndex = 51;
            this.label2.Text = "Impuesto Sobre Venta:";
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label1.Location = new System.Drawing.Point(163, 621);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 19);
            this.label1.TabIndex = 50;
            this.label1.Text = "Total:";
            this.label1.Visible = false;
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.BackColor = System.Drawing.Color.White;
            this.lblS.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblS.Location = new System.Drawing.Point(163, 531);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(81, 19);
            this.lblS.TabIndex = 49;
            this.lblS.Text = "SubTotal:";
            this.lblS.Visible = false;
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))));
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.FlatAppearance.BorderSize = 0;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.Location = new System.Drawing.Point(985, 620);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(61, 45);
            this.btnOk.TabIndex = 48;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Visible = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnFactura
            // 
            this.btnFactura.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))));
            this.btnFactura.FlatAppearance.BorderSize = 0;
            this.btnFactura.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFactura.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.btnFactura.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.btnFactura.Location = new System.Drawing.Point(787, 40);
            this.btnFactura.Name = "btnFactura";
            this.btnFactura.Size = new System.Drawing.Size(257, 28);
            this.btnFactura.TabIndex = 47;
            this.btnFactura.Text = "FACTURA";
            this.btnFactura.UseVisualStyleBackColor = false;
            this.btnFactura.Click += new System.EventHandler(this.btnFactura_Click);
            // 
            // dtpFact
            // 
            this.dtpFact.Enabled = false;
            this.dtpFact.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.dtpFact.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFact.Location = new System.Drawing.Point(621, 40);
            this.dtpFact.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtpFact.MinDate = new System.DateTime(2020, 12, 3, 0, 0, 0, 0);
            this.dtpFact.Name = "dtpFact";
            this.dtpFact.Size = new System.Drawing.Size(160, 28);
            this.dtpFact.TabIndex = 46;
            this.dtpFact.Value = new System.DateTime(2020, 12, 3, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label3.Location = new System.Drawing.Point(433, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 19);
            this.label3.TabIndex = 45;
            this.label3.Text = "Fecha de Factura:";
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource4.Name = "DsViaje";
            reportDataSource4.Value = this.ImprimirDetBindingSource;
            reportDataSource5.Name = "DsReserva";
            reportDataSource5.Value = this.ImprimirReservacionBindingSource;
            reportDataSource6.Name = "DsFact";
            reportDataSource6.Value = this.ImprimirFactBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource6);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "ProyectoFinal.RptFactura.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1058, 677);
            this.reportViewer1.TabIndex = 57;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // ImprimirDetTableAdapter
            // 
            this.ImprimirDetTableAdapter.ClearBeforeFill = true;
            // 
            // ImprimirReservacionTableAdapter
            // 
            this.ImprimirReservacionTableAdapter.ClearBeforeFill = true;
            // 
            // ImprimirFactTableAdapter
            // 
            this.ImprimirFactTableAdapter.ClearBeforeFill = true;
            // 
            // FormFactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(249)))), ((int)(((byte)(232)))));
            this.ClientSize = new System.Drawing.Size(1058, 677);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblIsv);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnFactura);
            this.Controls.Add(this.dtpFact);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormFactura";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormFactura";
            this.Load += new System.EventHandler(this.FormFactura_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirDetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.busesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirReservacionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImprimirFactBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblTotal;
        public System.Windows.Forms.Label lblIsv;
        public System.Windows.Forms.Label lblDesc;
        public System.Windows.Forms.Label lblSub;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Button btnOk;
        public System.Windows.Forms.Button btnFactura;
        public System.Windows.Forms.DateTimePicker dtpFact;
        public System.Windows.Forms.Label label3;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource ImprimirDetBindingSource;
        private busesDataSet busesDataSet;
        private System.Windows.Forms.BindingSource ImprimirReservacionBindingSource;
        private System.Windows.Forms.BindingSource ImprimirFactBindingSource;
        private busesDataSetTableAdapters.ImprimirDetTableAdapter ImprimirDetTableAdapter;
        private busesDataSetTableAdapters.ImprimirReservacionTableAdapter ImprimirReservacionTableAdapter;
        private busesDataSetTableAdapters.ImprimirFactTableAdapter ImprimirFactTableAdapter;
    }
}