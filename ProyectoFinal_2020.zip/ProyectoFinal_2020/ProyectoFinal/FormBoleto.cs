﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormBoleto : Form
    {
        public FormBoleto()
        {
            InitializeComponent();
        }

        private void FormBoleto_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'busesDataSet.ImprimirBoleto' table. You can move, or remove it, as needed.
            this.ImprimirBoletoTableAdapter.Fill(this.busesDataSet.ImprimirBoleto);

            this.reportViewer1.RefreshReport();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
