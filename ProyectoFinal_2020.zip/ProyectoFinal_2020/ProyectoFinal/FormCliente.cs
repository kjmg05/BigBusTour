﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  
using System.Data.Sql;

namespace ProyectoFinal
{
    public partial class FormCliente : Form
    {
        public FormCliente()
        {
            InitializeComponent();
        }

        ConecctionSql1 conect = new ConecctionSql1();
        SqlCommand comand = new SqlCommand();
        Cliente cliente = new Cliente();


        private void FormCliente_Load(object sender, EventArgs e)
        {
            conect.Abrir();
            conect.CargarDatosCliente(dgvClientes);
            btn_Mostrar.Visible = true;
        }

        private void FormCliente_FormClosed(object sender, FormClosedEventArgs e)
        {
            conect.Cerrar();
        }

        private void bttnGuardarC_Click(object sender, EventArgs e)
        {
            btn_Mostrar.Visible = true;
            btn_Modificar.Visible = false;

            try
            {
                if (txtIdentificacionC.Text == "" || txtNombreC.Text == "" || txtTelefonoC.Text == "" || (txtIdentificacionC.Text.Length < txtIdentificacionC.MaxLength))
                {
                    MessageBox.Show("¡ERROR...No puede dejar datos en blanco!", "ERROR!",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    cliente.Id = txtIdentificacionC.Text;
                    cliente.Nombre = txtNombreC.Text;
                    cliente.Fecha = Convert.ToDateTime(dateTimePicker1.Value.Date);
                    cliente.Telefono = txtTelefonoC.Text;
                    
                    SqlCommand SCommd = new SqlCommand("INSERT INTO clientes(identificacion, Nombre, FechaNac, Telefono)" +
                                               "VALUES (@identificacion, @Nombre, @FechaNac, @Telefono )", conect.sc);

                    SCommd.Parameters.AddWithValue("@identificacion", cliente.Id);
                    SCommd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                    SCommd.Parameters.AddWithValue("@FechaNac", cliente.Fecha);
                    SCommd.Parameters.AddWithValue("@Telefono", cliente.Telefono);
                    SCommd.CommandType = CommandType.Text;

                    SCommd.ExecuteNonQuery();

                    MessageBox.Show("Registro de cliente guardado correctamente", "AVISO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conect.CargarDatosCliente(dgvClientes);
                    txtIdentificacionC.Text = "";
                    txtNombreC.Text = "";
                    txtTelefonoC.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al insertar los datos o datos incompletos", "ERROR", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            try
            {
                string id;
                int indice;

                indice = dgvClientes.CurrentRow.Index;

                id = Convert.ToString(dgvClientes[0, indice].Value);
                dgvClientes[1, indice].Value = txtNombreC.Text;
                dgvClientes[2, indice].Value = Convert.ToDateTime(dateTimePicker1.Value.Date);
                dgvClientes[3, indice].Value = txtTelefonoC.Text;

                comand = new SqlCommand("update clientes set Nombre = '" + txtNombreC.Text + "' ,FechaNac = '" + Convert.ToDateTime(dateTimePicker1.Value.Date) + "', Telefono = '" + txtTelefonoC.Text + "' where identificacion = '" + id + "'", conect.sc);
                comand.ExecuteNonQuery();
                MessageBox.Show("Registro Actualizado con Exito", "Actualizar Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conect.CargarDatosCliente(dgvClientes);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo Actualizar el Registro", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            txtIdentificacionC.Text = "";
            txtNombreC.Text = "";
            txtTelefonoC.Text = "";
            btn_Modificar.Visible = false;
            bttnGuardarC.Visible = true;

        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            btn_Modificar.Visible = true;
            txtIdentificacionC.Text = dgvClientes.CurrentRow.Cells[0].Value.ToString();
            txtNombreC.Text = dgvClientes.CurrentRow.Cells[1].Value.ToString();
            txtTelefonoC.Text = dgvClientes.CurrentRow.Cells[3].Value.ToString();

            bttnGuardarC.Visible = false;
        }

        private void txtIdentificacionC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtNombreC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtTelefonoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}

