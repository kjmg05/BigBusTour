USE master
GO

GO
CREATE DATABASE buses
GO

GO
USE buses
GO

/*CREACION DE TABLAS*/
GO
CREATE TABLE Asiento
(
	[id_asiento] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[numero_asiento] [nvarchar](4) NOT NULL,
	[Estado] [nvarchar](7) NOT NULL,
	[id_bus] [int] NOT NULL
)
GO

GO
CREATE TABLE Boletos(
	[id_boleto] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[id_asiento] [int] NOT NULL,
	[id_reservacion] [int] NOT NULL
)
GO

GO
CREATE TABLE Bus
(
	[id_bus] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[placa] [nvarchar](7) NOT NULL,
	[modelo] [nvarchar](50) NOT NULL,
	[Capacidad] [int] NOT NULL
)
GO

GO
CREATE TABLE clientes
(
	[identificacion] [nchar](13) PRIMARY KEY NOT NULL,
	[Nombre] [nchar](50) NOT NULL,
	[FechaNac] [date] NOT NULL,
	[Telefono] [nchar](8) NOT NULL,
)
GO

GO
CREATE TABLE Destinos
(
	[id_destino] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[Nombre] [nchar](40) NOT NULL,
	[Costo] [money] NOT NULL
)
GO

GO
CREATE TABLE detalle_facturas
(
	[id_detalle] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[id_factura] [int] NOT NULL,
	[id_boleto] [int] NOT NULL,
	[tipo_viaje] [nvarchar](50) NOT NULL
)
GO

GO
CREATE TABLE Empleado
(
	[id_Empleado] [nchar](13) PRIMARY KEY NOT NULL,
	[Nombre] [nchar](50) NOT NULL,
	[Direccion] [nchar](100) NOT NULL,
	[Nacimiento] [date] NOT NULL,
	[Contratacion] [date] NOT NULL,
	[Telefono] [nchar](8) NOT NULL,
	[id_usuario] [int] NOT NULL
)
GO

GO
CREATE TABLE Facturas
(
	[id_factura] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[fecha] [date] NOT NULL
)
GO

GO
CREATE TABLE Reservaciones
(
	[id_reservacion] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[hora_reservacion] [nvarchar](4) NOT NULL,
	[fecha_reservacion] [date] NOT NULL,
	[identificacion_cliente] [nchar](13) NOT NULL,
	[id_destinos] [int] NOT NULL
)
GO

GO
CREATE TABLE Roles_Usuario
(
	[id_Rol] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[Rol] [nchar](40) NULL
)
GO

GO
CREATE TABLE Usuarios
(
	[id_usuario] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[username] [nchar](20) NOT NULL,
	[password] [nchar](20) NOT NULL,
	[id_Rol] [int] NOT NULL
)
GO
/*FIN CREACION DE TABLAS*/

/*CREACION DE LLAVES FORANEAS*/
ALTER TABLE [dbo].[Asiento]  WITH CHECK ADD  CONSTRAINT [FK_Asiento_Bus] FOREIGN KEY([id_bus])
REFERENCES [dbo].[Bus] ([id_bus])
GO
ALTER TABLE [dbo].[Asiento] CHECK CONSTRAINT [FK_Asiento_Bus]
GO

ALTER TABLE [dbo].[Boletos]  WITH CHECK ADD  CONSTRAINT [FK_Boletos_Asiento] FOREIGN KEY([id_asiento])
REFERENCES [dbo].[Asiento] ([id_asiento])
GO
ALTER TABLE [dbo].[Boletos] CHECK CONSTRAINT [FK_Boletos_Asiento]
GO

ALTER TABLE [dbo].[Boletos]  WITH CHECK ADD  CONSTRAINT [FK_Boletos_Reservaciones] FOREIGN KEY([id_reservacion])
REFERENCES [dbo].[Reservaciones] ([id_reservacion])
GO
ALTER TABLE [dbo].[Boletos] CHECK CONSTRAINT [FK_Boletos_Reservaciones]
GO

ALTER TABLE [dbo].[detalle_facturas]  WITH CHECK ADD  CONSTRAINT [FK_detalle_facturas_Boletos] FOREIGN KEY([id_boleto])
REFERENCES [dbo].[Boletos] ([id_boleto])
GO
ALTER TABLE [dbo].[detalle_facturas] CHECK CONSTRAINT [FK_detalle_facturas_Boletos]
GO

ALTER TABLE [dbo].[detalle_facturas]  WITH CHECK ADD  CONSTRAINT [FK_detalle_facturas_Facturas] FOREIGN KEY([id_factura])
REFERENCES [dbo].[Facturas] ([id_factura])
GO
ALTER TABLE [dbo].[detalle_facturas] CHECK CONSTRAINT [FK_detalle_facturas_Facturas]
GO

ALTER TABLE [dbo].[Empleado]  WITH CHECK ADD  CONSTRAINT [FK_Empleado_Usuarios] FOREIGN KEY([id_usuario])
REFERENCES [dbo].[Usuarios] ([id_usuario])
GO
ALTER TABLE [dbo].[Empleado] CHECK CONSTRAINT [FK_Empleado_Usuarios]
GO

ALTER TABLE [dbo].[Reservaciones]  WITH CHECK ADD  CONSTRAINT [FK_Reservaciones_clientes] FOREIGN KEY([identificacion_cliente])
REFERENCES [dbo].[clientes] ([identificacion])
GO
ALTER TABLE [dbo].[Reservaciones] CHECK CONSTRAINT [FK_Reservaciones_clientes]
GO

ALTER TABLE [dbo].[Reservaciones]  WITH CHECK ADD  CONSTRAINT [FK_Reservaciones_Destinos] FOREIGN KEY([id_destinos])
REFERENCES [dbo].[Destinos] ([id_destino])
GO
ALTER TABLE [dbo].[Reservaciones] CHECK CONSTRAINT [FK_Reservaciones_Destinos]
GO

ALTER TABLE [dbo].[Usuarios]  WITH CHECK ADD  CONSTRAINT [FK_Usuarios_Roles_Usuario] FOREIGN KEY([id_Rol])
REFERENCES [dbo].[Roles_Usuario] ([id_Rol])
GO
ALTER TABLE [dbo].[Usuarios] CHECK CONSTRAINT [FK_Usuarios_Roles_Usuario]
GO
/*FIN CREACION LLAVES FORANEAS*/

/*PROCEDIMIENTOS ALMACENADOS*/
CREATE PROCEDURE ActualizarBus
	@idBus int,
	@placa nvarchar(7),
	@mod nvarchar(50), 
	@c int
AS
BEGIN
	SET NOCOUNT ON;
	update Bus set placa = @placa, modelo = @mod, Capacidad = @c where id_bus = @idBus
END
GO

CREATE PROCEDURE BuscarAsiento
	@id nvarchar(7),
	@bus int
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [Estado] from [dbo].[Asiento]
	where [numero_asiento] = @id and id_bus = @bus
END
GO

CREATE PROCEDURE BuscarAsientoCodigo
	@id nvarchar(4)
AS
BEGIN
	SET NOCOUNT ON;
	select id_asiento from Asiento
	where numero_asiento = @id
END
GO

CREATE PROCEDURE BuscarCliente
	@idCliente nchar(13)
AS
BEGIN
	SET NOCOUNT ON;
	select [Nombre] from [dbo].[clientes]
	WHERE identificacion = @idCliente
END
GO

CREATE PROCEDURE BusCb
AS
BEGIN
	SET NOCOUNT ON;
	select [placa] from [dbo].[Bus]
END
GO

CREATE PROCEDURE CargaBus
AS
BEGIN
	SET NOCOUNT ON;
	SELECT id_bus 'Id. Bus', [placa] 'Placa', [modelo] 'Modelo', [Capacidad]
	FROM [dbo].[Bus]
END
GO

CREATE PROCEDURE CargaCliente
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [identificacion] 'Id. Cliente', [Nombre] 'Nombre Cliente', [FechaNac] 'Fecha Nacimiento', [Telefono] 'Tel. Contacto'
	FROM [dbo].[clientes]
	
END
GO

CREATE PROCEDURE CargaDestino
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [id_destino] 'N� Destino', [Nombre] 'Nombre del Destino', [Costo]
	FROM [dbo].[Destinos]
END
GO

CREATE PROCEDURE CargaEmpleado
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [id_Empleado] 'Id. Empleado', [Nombre] 'Nombre Empleado', [Nacimiento] 'Fecha Nacimiento', [Contratacion] 'Fecha Contrataci�n', [Telefono] 'Tel. Contacto'
	FROM [dbo].[Empleado]
	
END
GO

CREATE PROCEDURE ComboBox
AS
BEGIN
	SET NOCOUNT ON;
	select [Rol] from [dbo].[Roles_Usuario]
END
GO

CREATE PROCEDURE DestinosCb
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [Nombre], [Costo] FROM [dbo].[Destinos]
END
GO

CREATE PROCEDURE EstadoAsiento
	@idAsiento nvarchar(4),
	@estado nchar(30),
	@bus int
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE Asiento SET Estado = @estado
	WHERE numero_asiento = @idAsiento and id_bus = @bus
END
GO

CREATE PROC ImprimirBoleto
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 1 id_boleto, id_asiento, id_reservacion
	FROM Boletos
	ORDER BY id_boleto DESC
END
GO

CREATE PROC ImprimirDet
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 1 tipo_viaje
	FROM detalle_facturas
	ORDER BY id_detalle DESC
END
GO

CREATE PROC ImprimirFact
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 1 id_factura, Convert (VARCHAR(10), fecha, 103)fecha
	from Facturas
	ORDER BY id_factura DESC
END
GO

CREATE PROC ImprimirReservacion
AS
BEGIN
	SET NOCOUNT ON;
	SELECT TOP 1 id_reservacion, id_destinos, hora_reservacion, Convert (VARCHAR(10), fecha_reservacion, 103) Fecha, identificacion_cliente
	FROM Reservaciones
	ORDER BY id_reservacion DESC
END
GO

CREATE PROCEDURE IngresarBoleto
	@idAsiento int,
	@idRes int,
	@idBoleto int output
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO [dbo].[Boletos] VALUES (@idAsiento, @idRes) SET @idBoleto = SCOPE_IDENTITY();    
	return @idBoleto
END
GO

CREATE PROCEDURE IngresarReservacion
	@hora nvarchar(4),
	@fecha as date,
	@idCliente nchar(13),
	@idDestino int,
	@id int output
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Reservaciones VALUES (@hora, @fecha, @idCliente, @idDestino) SET @id = SCOPE_IDENTITY();    
	RETURN @id
END
GO

CREATE PROCEDURE IngresarUsuario
	@name as nchar(20),
	@pass as nchar(20),
	@rol as int,
	@id as int output
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Usuarios VALUES (@name, @pass, @rol) SET @id = SCOPE_IDENTITY();    
	RETURN @id
END
GO

CREATE PROCEDURE InicioSesion
	@pass as nchar(20),
	@user as nchar(20)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT  t1.id_Rol, t2.Nombre FROM Usuarios t1 INNER JOIN Empleado t2
	ON t1.id_usuario = t2.id_usuario
	WHERE username = @user and password = @pass
END
GO

CREATE PROCEDURE InsertarAsiento
	@num nchar(10),
	@estado nchar(30),
	@id int
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Asiento VALUES (UPPER(@num), @estado, @id)
END
GO

CREATE PROCEDURE InsertarBus
	@placa nvarchar(7),
	@modelo nvarchar(50),
	@num int,
	@id int output
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Bus VALUES (UPPER(@placa), @modelo, @num) SET @id = SCOPE_IDENTITY();    
	RETURN @id
END
GO

CREATE PROCEDURE InsertarDetalle
@fact int,
@boleto int,
@viaje nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO detalle_facturas VALUES (@fact, @boleto, @viaje)
END
GO

CREATE PROCEDURE InsertarEmpleado
	@id nchar(13),
	@nombre nchar(50),
	@direccion nchar(100),
	@nac date,
	@con date, 
	@tel nchar(8),
	@idUser int
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Empleado VALUES (@id, @nombre, @direccion, @nac, @con, @tel, @idUser)
END
GO

CREATE PROCEDURE InsertarFact
@idFact int output,
@fecha date
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO Facturas VALUES (@fecha) SET @idFact = SCOPE_IDENTITY();
	RETURN @idFact
END
GO

CREATE PROCEDURE RptReservaciones
AS
BEGIN
	SET NOCOUNT ON;
	SELECT t1.id_reservacion, t1.[hora_reservacion], (t1.[id_destinos]), t2.Nombre, month(t1.[fecha_reservacion]) Mes
	FROM Reservaciones t1 INNER JOIN Destinos t2 on t1.id_destinos = t2.id_destino
END
GO

CREATE PROCEDURE RptViajes
AS
BEGIN
	SET NOCOUNT ON;
	SELECT t5.Nombre, t2.placa, COUNT(t4.id_reservacion) Viajes
	FROM Asiento t1 inner join Bus t2 on t1.id_bus = t2.id_bus inner join Boletos t3 on t1.id_asiento = t3.id_asiento
	inner join Reservaciones t4 on t3.id_reservacion = t4.id_reservacion inner join Destinos t5 on t4.id_destinos= t5.id_destino
	GROUP BY t5.Nombre, t2.placa
END
GO

GO
CREATE PROCEDURE CostoDestino
	@idDes int
AS
BEGIN
	SET NOCOUNT ON;
	select costo from Destinos where id_destino = @idDes
END
GO

GO
CREATE PROCEDURE InfoClienteFrecuente
	@idC nchar(13)
AS
BEGIN
	SET NOCOUNT ON;
	select COUNT(id_reservacion), identificacion_cliente from Reservaciones where identificacion_cliente = @idC
	GROUP BY identificacion_cliente
END
GO

/*FIN PROCEDIMIENTOS*/

/*INSERT VALUES INTO EMPLEADOS, USUARIOS AND ROLES*/

INSERT INTO Roles_Usuario VALUES ('Usuario Administrador')
INSERT INTO Roles_Usuario VALUES ('Usuario General')

INSERT INTO Usuarios VALUES ('kjmg', 'kjmg', 1)

INSERT INTO Empleado VALUES ('0703199703840', 'Kenia Julissa Martinez', 'UNICAH', '1997-08-05', '2020-12-07', '33898669', 1)
/*FIN INSERT*/

