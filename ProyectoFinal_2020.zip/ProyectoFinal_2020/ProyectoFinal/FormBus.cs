﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormBus : Form
    {
        public FormBus()
        {
            InitializeComponent();
        }

        AutoBus bus = new AutoBus();

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                bus.Placa = txtPlaca.Text;
                bus.Modelo = txtModelo.Text;
                bus.Capacidad = Convert.ToInt32(Math.Round(numCapacidad.Value, 0));
                bus.InsertarBus();
                btnGuardar.Enabled = false;
                btnAsiento.Visible = true;
                txtPlaca.Enabled = false;
                txtModelo.Enabled = false;
                
                bus.CargaDatos("exec CargaBus", dgvBus);
                txtModelo.Clear();
                txtPlaca.Clear();
            }
            
        }

        private void btnAsiento_Click(object sender, EventArgs e)
        {
            FormAsiento asiento = new FormAsiento();
            asiento.ShowDialog();
            btnAsiento.Visible = false;
            txtPlaca.Enabled = true;
            txtModelo.Enabled = true;
            btnGuardar.Enabled = true;
        }

        private void FormBus_Load(object sender, EventArgs e)
        {
            bus.CargaDatos("exec CargaBus", dgvBus);
        }

        private void FormBus_FormClosed(object sender, FormClosedEventArgs e)
        {
            bus.Connection.Close();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            btnAcualizar.Visible = true;
            grb.Visible = false;
            txtPlaca.Text = dgvBus.CurrentRow.Cells[1].Value.ToString();
            txtModelo.Text = dgvBus.CurrentRow.Cells[2].Value.ToString();
        }

        private void btnAcualizar_Click(object sender, EventArgs e)
        {
            int i, code;
            i = dgvBus.CurrentRow.Index;

            try
            {
                code = Convert.ToInt32(dgvBus[0, i].Value);
                string placa = txtPlaca.Text;
                string modelo = txtModelo.Text;
                bus.Capacidad = Convert.ToInt32(Math.Round(numCapacidad.Value, 0));
                dgvBus[1, i].Value = txtPlaca.Text;
                dgvBus[2, i].Value = txtModelo.Text;
                dgvBus[3, i].Value = bus.Capacidad;
                bus.ActualizarBus(code, placa, modelo);
                bus.CargaDatos("exec CargaBus", dgvBus);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al Actualizar el Registro", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            btnAcualizar.Visible = false;
            grb.Visible = true;
            txtModelo.Clear();
            txtPlaca.Clear();
        }

        private void txtPlaca_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtPlaca.Text) || (txtPlaca.Text.Length < txtPlaca.MaxLength))
            {
                e.Cancel = true;
                txtPlaca.Focus();
                errorTxt.SetError(txtPlaca, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtPlaca, null);
            }
        }

        private void txtPlaca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtModelo_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtModelo.Text))
            {
                e.Cancel = true;
                txtModelo.Focus();
                errorTxt.SetError(txtModelo, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtModelo, null);
            }
        }

        private void txtModelo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
