﻿namespace ProyectoFinal
{
    partial class FormReservacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnA1 = new System.Windows.Forms.Button();
            this.grbAsiento = new System.Windows.Forms.GroupBox();
            this.btnA3 = new System.Windows.Forms.Button();
            this.btnAsiento = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnD1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnA2 = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnD4 = new System.Windows.Forms.Button();
            this.btnC4 = new System.Windows.Forms.Button();
            this.btnB4 = new System.Windows.Forms.Button();
            this.btnD3 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.btnA4 = new System.Windows.Forms.Button();
            this.btnB3 = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnC1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.cbBus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb10 = new System.Windows.Forms.CheckBox();
            this.cb12 = new System.Windows.Forms.CheckBox();
            this.cb09 = new System.Windows.Forms.CheckBox();
            this.cb13 = new System.Windows.Forms.CheckBox();
            this.cb11 = new System.Windows.Forms.CheckBox();
            this.cb08 = new System.Windows.Forms.CheckBox();
            this.dtReservacion = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbVuelta = new System.Windows.Forms.RadioButton();
            this.rbIda = new System.Windows.Forms.RadioButton();
            this.cbDestinos = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnFact = new System.Windows.Forms.Button();
            this.btnBoleto = new System.Windows.Forms.Button();
            this.pbBuscar = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblBoleto = new System.Windows.Forms.Label();
            this.lblReserva = new System.Windows.Forms.Label();
            this.errorTxt = new System.Windows.Forms.ErrorProvider(this.components);
            this.grbAsiento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorTxt)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label4.Location = new System.Drawing.Point(55, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 28);
            this.label4.TabIndex = 22;
            this.label4.Text = "RESERVACIONES";
            // 
            // btnB1
            // 
            this.btnB1.BackColor = System.Drawing.Color.LightGray;
            this.btnB1.Location = new System.Drawing.Point(482, 269);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(55, 40);
            this.btnB1.TabIndex = 23;
            this.btnB1.Text = "B-1";
            this.btnB1.UseVisualStyleBackColor = false;
            this.btnB1.Click += new System.EventHandler(this.btnB1_Click);
            // 
            // btnA1
            // 
            this.btnA1.BackColor = System.Drawing.Color.LightGray;
            this.btnA1.Location = new System.Drawing.Point(402, 269);
            this.btnA1.Name = "btnA1";
            this.btnA1.Size = new System.Drawing.Size(55, 40);
            this.btnA1.TabIndex = 24;
            this.btnA1.Text = "A-1";
            this.btnA1.UseVisualStyleBackColor = false;
            this.btnA1.Click += new System.EventHandler(this.btnA1_Click);
            // 
            // grbAsiento
            // 
            this.grbAsiento.Controls.Add(this.btnA3);
            this.grbAsiento.Controls.Add(this.btnAsiento);
            this.grbAsiento.Controls.Add(this.label3);
            this.grbAsiento.Controls.Add(this.label2);
            this.grbAsiento.Controls.Add(this.label1);
            this.grbAsiento.Controls.Add(this.pictureBox1);
            this.grbAsiento.Controls.Add(this.btnD1);
            this.grbAsiento.Controls.Add(this.btnC2);
            this.grbAsiento.Controls.Add(this.btnA2);
            this.grbAsiento.Controls.Add(this.btnB2);
            this.grbAsiento.Controls.Add(this.btnD4);
            this.grbAsiento.Controls.Add(this.btnC4);
            this.grbAsiento.Controls.Add(this.btnB4);
            this.grbAsiento.Controls.Add(this.btnD3);
            this.grbAsiento.Controls.Add(this.btnC3);
            this.grbAsiento.Controls.Add(this.btnA4);
            this.grbAsiento.Controls.Add(this.btnB3);
            this.grbAsiento.Controls.Add(this.btnD2);
            this.grbAsiento.Controls.Add(this.btnC1);
            this.grbAsiento.Controls.Add(this.btnA1);
            this.grbAsiento.Controls.Add(this.btnB1);
            this.grbAsiento.Enabled = false;
            this.grbAsiento.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.grbAsiento.Location = new System.Drawing.Point(159, 438);
            this.grbAsiento.Name = "grbAsiento";
            this.grbAsiento.Size = new System.Drawing.Size(735, 331);
            this.grbAsiento.TabIndex = 25;
            this.grbAsiento.TabStop = false;
            this.grbAsiento.Text = "ASIENTOS";
            // 
            // btnA3
            // 
            this.btnA3.BackColor = System.Drawing.Color.LightGray;
            this.btnA3.Location = new System.Drawing.Point(402, 21);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(55, 40);
            this.btnA3.TabIndex = 59;
            this.btnA3.Text = "A-3";
            this.btnA3.UseVisualStyleBackColor = false;
            this.btnA3.Click += new System.EventHandler(this.btnA3_Click);
            // 
            // btnAsiento
            // 
            this.btnAsiento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(109)))), ((int)(((byte)(140)))));
            this.btnAsiento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAsiento.FlatAppearance.BorderSize = 0;
            this.btnAsiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAsiento.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsiento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.btnAsiento.Location = new System.Drawing.Point(93, 74);
            this.btnAsiento.Name = "btnAsiento";
            this.btnAsiento.Size = new System.Drawing.Size(200, 30);
            this.btnAsiento.TabIndex = 64;
            this.btnAsiento.Text = "Guardar Asiento";
            this.btnAsiento.UseVisualStyleBackColor = false;
            this.btnAsiento.Click += new System.EventHandler(this.btnAsiento_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(246, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 21);
            this.label3.TabIndex = 58;
            this.label3.Text = "ELEGIDO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(113, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 21);
            this.label2.TabIndex = 57;
            this.label2.Text = "OCUPADO";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(33, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 21);
            this.label1.TabIndex = 56;
            this.label1.Text = "LIBRE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProyectoFinal.Properties.Resources._661611_200;
            this.pictureBox1.Location = new System.Drawing.Point(82, 235);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 55;
            this.pictureBox1.TabStop = false;
            // 
            // btnD1
            // 
            this.btnD1.BackColor = System.Drawing.Color.LightGray;
            this.btnD1.Location = new System.Drawing.Point(642, 268);
            this.btnD1.Name = "btnD1";
            this.btnD1.Size = new System.Drawing.Size(55, 40);
            this.btnD1.TabIndex = 51;
            this.btnD1.Text = "D-1";
            this.btnD1.UseVisualStyleBackColor = false;
            this.btnD1.Click += new System.EventHandler(this.btnD1_Click);
            // 
            // btnC2
            // 
            this.btnC2.BackColor = System.Drawing.Color.LightGray;
            this.btnC2.Location = new System.Drawing.Point(562, 209);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(55, 40);
            this.btnC2.TabIndex = 49;
            this.btnC2.Text = "C-2";
            this.btnC2.UseVisualStyleBackColor = false;
            this.btnC2.Click += new System.EventHandler(this.btnC2_Click);
            // 
            // btnA2
            // 
            this.btnA2.BackColor = System.Drawing.Color.LightGray;
            this.btnA2.Location = new System.Drawing.Point(402, 209);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(55, 40);
            this.btnA2.TabIndex = 48;
            this.btnA2.Text = "A-2";
            this.btnA2.UseVisualStyleBackColor = false;
            this.btnA2.Click += new System.EventHandler(this.btnA2_Click);
            // 
            // btnB2
            // 
            this.btnB2.BackColor = System.Drawing.Color.LightGray;
            this.btnB2.Location = new System.Drawing.Point(482, 209);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(55, 40);
            this.btnB2.TabIndex = 47;
            this.btnB2.Text = "B-2";
            this.btnB2.UseVisualStyleBackColor = false;
            this.btnB2.Click += new System.EventHandler(this.btnB2_Click);
            // 
            // btnD4
            // 
            this.btnD4.BackColor = System.Drawing.Color.LightGray;
            this.btnD4.Location = new System.Drawing.Point(642, 21);
            this.btnD4.Name = "btnD4";
            this.btnD4.Size = new System.Drawing.Size(55, 40);
            this.btnD4.TabIndex = 43;
            this.btnD4.Text = "D-4";
            this.btnD4.UseVisualStyleBackColor = false;
            this.btnD4.Click += new System.EventHandler(this.btnD4_Click);
            // 
            // btnC4
            // 
            this.btnC4.BackColor = System.Drawing.Color.LightGray;
            this.btnC4.Location = new System.Drawing.Point(562, 21);
            this.btnC4.Name = "btnC4";
            this.btnC4.Size = new System.Drawing.Size(55, 40);
            this.btnC4.TabIndex = 41;
            this.btnC4.Text = "C-4";
            this.btnC4.UseVisualStyleBackColor = false;
            this.btnC4.Click += new System.EventHandler(this.btnC4_Click);
            // 
            // btnB4
            // 
            this.btnB4.BackColor = System.Drawing.Color.LightGray;
            this.btnB4.Location = new System.Drawing.Point(482, 21);
            this.btnB4.Name = "btnB4";
            this.btnB4.Size = new System.Drawing.Size(55, 40);
            this.btnB4.TabIndex = 39;
            this.btnB4.Text = "B-4";
            this.btnB4.UseVisualStyleBackColor = false;
            this.btnB4.Click += new System.EventHandler(this.btnB4_Click);
            // 
            // btnD3
            // 
            this.btnD3.BackColor = System.Drawing.Color.LightGray;
            this.btnD3.Location = new System.Drawing.Point(642, 80);
            this.btnD3.Name = "btnD3";
            this.btnD3.Size = new System.Drawing.Size(55, 40);
            this.btnD3.TabIndex = 35;
            this.btnD3.Text = "D-3";
            this.btnD3.UseVisualStyleBackColor = false;
            this.btnD3.Click += new System.EventHandler(this.btnD3_Click);
            // 
            // btnC3
            // 
            this.btnC3.BackColor = System.Drawing.Color.LightGray;
            this.btnC3.Location = new System.Drawing.Point(562, 80);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(55, 40);
            this.btnC3.TabIndex = 33;
            this.btnC3.Text = "C-3";
            this.btnC3.UseVisualStyleBackColor = false;
            this.btnC3.Click += new System.EventHandler(this.btnC3_Click);
            // 
            // btnA4
            // 
            this.btnA4.BackColor = System.Drawing.Color.LightGray;
            this.btnA4.Location = new System.Drawing.Point(402, 80);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(55, 40);
            this.btnA4.TabIndex = 32;
            this.btnA4.Text = "A-4";
            this.btnA4.UseVisualStyleBackColor = false;
            this.btnA4.Click += new System.EventHandler(this.btnA4_Click);
            // 
            // btnB3
            // 
            this.btnB3.BackColor = System.Drawing.Color.LightGray;
            this.btnB3.Location = new System.Drawing.Point(482, 80);
            this.btnB3.Name = "btnB3";
            this.btnB3.Size = new System.Drawing.Size(55, 40);
            this.btnB3.TabIndex = 31;
            this.btnB3.Text = "B-3";
            this.btnB3.UseVisualStyleBackColor = false;
            this.btnB3.Click += new System.EventHandler(this.btnB3_Click);
            // 
            // btnD2
            // 
            this.btnD2.BackColor = System.Drawing.Color.LightGray;
            this.btnD2.Location = new System.Drawing.Point(642, 209);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(55, 40);
            this.btnD2.TabIndex = 27;
            this.btnD2.Text = "D-2";
            this.btnD2.UseVisualStyleBackColor = false;
            this.btnD2.Click += new System.EventHandler(this.btnD2_Click);
            // 
            // btnC1
            // 
            this.btnC1.BackColor = System.Drawing.Color.LightGray;
            this.btnC1.Location = new System.Drawing.Point(562, 269);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(55, 40);
            this.btnC1.TabIndex = 25;
            this.btnC1.Text = "C-1";
            this.btnC1.UseVisualStyleBackColor = false;
            this.btnC1.Click += new System.EventHandler(this.btnC1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label12.Location = new System.Drawing.Point(625, 376);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 19);
            this.label12.TabIndex = 65;
            this.label12.Text = "Elija un autobus";
            // 
            // cbBus
            // 
            this.cbBus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(109)))), ((int)(((byte)(140)))));
            this.cbBus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBus.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.cbBus.FormattingEnabled = true;
            this.cbBus.Location = new System.Drawing.Point(778, 372);
            this.cbBus.Name = "cbBus";
            this.cbBus.Size = new System.Drawing.Size(227, 29);
            this.cbBus.TabIndex = 66;
            this.cbBus.SelectedIndexChanged += new System.EventHandler(this.cbBus_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label6.Location = new System.Drawing.Point(258, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 19);
            this.label6.TabIndex = 38;
            this.label6.Text = "Destino";
            // 
            // txtCliente
            // 
            this.txtCliente.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.txtCliente.Location = new System.Drawing.Point(206, 109);
            this.txtCliente.MaxLength = 13;
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(308, 28);
            this.txtCliente.TabIndex = 35;
            this.txtCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCliente_KeyPress);
            this.txtCliente.Validating += new System.ComponentModel.CancelEventHandler(this.txtCliente_Validating);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label7.Location = new System.Drawing.Point(110, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 19);
            this.label7.TabIndex = 34;
            this.label7.Text = "Cliente:";
            // 
            // txtNombre
            // 
            this.txtNombre.Enabled = false;
            this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.txtNombre.Location = new System.Drawing.Point(733, 109);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(352, 28);
            this.txtNombre.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label8.Location = new System.Drawing.Point(625, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 19);
            this.label8.TabIndex = 40;
            this.label8.Text = "Nombre:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb10);
            this.groupBox2.Controls.Add(this.cb12);
            this.groupBox2.Controls.Add(this.cb09);
            this.groupBox2.Controls.Add(this.cb13);
            this.groupBox2.Controls.Add(this.cb11);
            this.groupBox2.Controls.Add(this.cb08);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.groupBox2.Location = new System.Drawing.Point(629, 230);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(528, 136);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Horario";
            // 
            // cb10
            // 
            this.cb10.AutoSize = true;
            this.cb10.Location = new System.Drawing.Point(367, 45);
            this.cb10.Name = "cb10";
            this.cb10.Size = new System.Drawing.Size(105, 25);
            this.cb10.TabIndex = 5;
            this.cb10.Text = "10:00 am";
            this.cb10.UseVisualStyleBackColor = true;
            this.cb10.CheckedChanged += new System.EventHandler(this.cb10_CheckedChanged);
            // 
            // cb12
            // 
            this.cb12.AutoSize = true;
            this.cb12.Location = new System.Drawing.Point(207, 77);
            this.cb12.Name = "cb12";
            this.cb12.Size = new System.Drawing.Size(105, 25);
            this.cb12.TabIndex = 4;
            this.cb12.Text = "12:00 pm";
            this.cb12.UseVisualStyleBackColor = true;
            this.cb12.CheckedChanged += new System.EventHandler(this.cb12_CheckedChanged);
            // 
            // cb09
            // 
            this.cb09.AutoSize = true;
            this.cb09.Location = new System.Drawing.Point(207, 45);
            this.cb09.Name = "cb09";
            this.cb09.Size = new System.Drawing.Size(105, 25);
            this.cb09.TabIndex = 3;
            this.cb09.Text = "09:00 am";
            this.cb09.UseVisualStyleBackColor = true;
            this.cb09.CheckedChanged += new System.EventHandler(this.cb09_CheckedChanged);
            // 
            // cb13
            // 
            this.cb13.AutoSize = true;
            this.cb13.Location = new System.Drawing.Point(367, 77);
            this.cb13.Name = "cb13";
            this.cb13.Size = new System.Drawing.Size(105, 25);
            this.cb13.TabIndex = 2;
            this.cb13.Text = "13:00 pm";
            this.cb13.UseVisualStyleBackColor = true;
            this.cb13.CheckedChanged += new System.EventHandler(this.cb13_CheckedChanged);
            // 
            // cb11
            // 
            this.cb11.AutoSize = true;
            this.cb11.Location = new System.Drawing.Point(47, 77);
            this.cb11.Name = "cb11";
            this.cb11.Size = new System.Drawing.Size(105, 25);
            this.cb11.TabIndex = 1;
            this.cb11.Text = "11:00 am";
            this.cb11.UseVisualStyleBackColor = true;
            this.cb11.CheckedChanged += new System.EventHandler(this.cb11_CheckedChanged);
            // 
            // cb08
            // 
            this.cb08.AutoSize = true;
            this.cb08.Location = new System.Drawing.Point(47, 45);
            this.cb08.Name = "cb08";
            this.cb08.Size = new System.Drawing.Size(105, 25);
            this.cb08.TabIndex = 0;
            this.cb08.Text = "08:00 am";
            this.cb08.UseVisualStyleBackColor = true;
            this.cb08.CheckedChanged += new System.EventHandler(this.cb08_CheckedChanged);
            // 
            // dtReservacion
            // 
            this.dtReservacion.Enabled = false;
            this.dtReservacion.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.dtReservacion.Location = new System.Drawing.Point(733, 171);
            this.dtReservacion.MinDate = new System.DateTime(2020, 12, 1, 0, 0, 0, 0);
            this.dtReservacion.Name = "dtReservacion";
            this.dtReservacion.Size = new System.Drawing.Size(352, 28);
            this.dtReservacion.TabIndex = 44;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label5.Location = new System.Drawing.Point(625, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 19);
            this.label5.TabIndex = 43;
            this.label5.Text = "Fecha:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbVuelta);
            this.groupBox3.Controls.Add(this.rbIda);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.groupBox3.Location = new System.Drawing.Point(114, 168);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(371, 80);
            this.groupBox3.TabIndex = 43;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Boleto";
            // 
            // rbVuelta
            // 
            this.rbVuelta.AutoSize = true;
            this.rbVuelta.Location = new System.Drawing.Point(200, 37);
            this.rbVuelta.Name = "rbVuelta";
            this.rbVuelta.Size = new System.Drawing.Size(134, 25);
            this.rbVuelta.TabIndex = 1;
            this.rbVuelta.TabStop = true;
            this.rbVuelta.Text = "Ida y Vuelta";
            this.rbVuelta.UseVisualStyleBackColor = true;
            // 
            // rbIda
            // 
            this.rbIda.AutoSize = true;
            this.rbIda.Location = new System.Drawing.Point(45, 36);
            this.rbIda.Name = "rbIda";
            this.rbIda.Size = new System.Drawing.Size(98, 25);
            this.rbIda.TabIndex = 0;
            this.rbIda.TabStop = true;
            this.rbIda.Text = "Solo Ida";
            this.rbIda.UseVisualStyleBackColor = true;
            // 
            // cbDestinos
            // 
            this.cbDestinos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(109)))), ((int)(((byte)(140)))));
            this.cbDestinos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDestinos.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.cbDestinos.FormattingEnabled = true;
            this.cbDestinos.Location = new System.Drawing.Point(114, 372);
            this.cbDestinos.Name = "cbDestinos";
            this.cbDestinos.Size = new System.Drawing.Size(230, 29);
            this.cbDestinos.TabIndex = 46;
            this.cbDestinos.SelectedIndexChanged += new System.EventHandler(this.cbDestinos_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label10.Location = new System.Drawing.Point(1163, 474);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 19);
            this.label10.TabIndex = 48;
            this.label10.Text = "Reservacion:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.label11.Location = new System.Drawing.Point(1163, 512);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 19);
            this.label11.TabIndex = 49;
            this.label11.Text = "Boleto:";
            // 
            // btnFact
            // 
            this.btnFact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(109)))), ((int)(((byte)(140)))));
            this.btnFact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFact.FlatAppearance.BorderSize = 0;
            this.btnFact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFact.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFact.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.btnFact.Location = new System.Drawing.Point(1235, 697);
            this.btnFact.Name = "btnFact";
            this.btnFact.Size = new System.Drawing.Size(200, 30);
            this.btnFact.TabIndex = 60;
            this.btnFact.Text = "FACTURA";
            this.btnFact.UseVisualStyleBackColor = false;
            this.btnFact.Visible = false;
            this.btnFact.Click += new System.EventHandler(this.btnFact_Click);
            // 
            // btnBoleto
            // 
            this.btnBoleto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(109)))), ((int)(((byte)(140)))));
            this.btnBoleto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBoleto.FlatAppearance.BorderSize = 0;
            this.btnBoleto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBoleto.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBoleto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.btnBoleto.Location = new System.Drawing.Point(1167, 553);
            this.btnBoleto.Name = "btnBoleto";
            this.btnBoleto.Size = new System.Drawing.Size(200, 30);
            this.btnBoleto.TabIndex = 61;
            this.btnBoleto.Text = "Guardar Boleto";
            this.btnBoleto.UseVisualStyleBackColor = false;
            this.btnBoleto.Visible = false;
            this.btnBoleto.Click += new System.EventHandler(this.btnBoleto_Click);
            // 
            // pbBuscar
            // 
            this.pbBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbBuscar.Image = global::ProyectoFinal.Properties.Resources._1491254410_searchfinddetailzoom_82949;
            this.pbBuscar.Location = new System.Drawing.Point(535, 109);
            this.pbBuscar.Name = "pbBuscar";
            this.pbBuscar.Size = new System.Drawing.Size(28, 28);
            this.pbBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBuscar.TabIndex = 62;
            this.pbBuscar.TabStop = false;
            this.pbBuscar.Click += new System.EventHandler(this.pbBuscar_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProyectoFinal.Properties.Resources.lugare;
            this.pictureBox2.Location = new System.Drawing.Point(114, 291);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(371, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCosto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblCosto.Location = new System.Drawing.Point(370, 376);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(16, 19);
            this.lblCosto.TabIndex = 63;
            this.lblCosto.Text = "-";
            // 
            // lblBoleto
            // 
            this.lblBoleto.AutoSize = true;
            this.lblBoleto.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblBoleto.Location = new System.Drawing.Point(1298, 512);
            this.lblBoleto.Name = "lblBoleto";
            this.lblBoleto.Size = new System.Drawing.Size(16, 19);
            this.lblBoleto.TabIndex = 64;
            this.lblBoleto.Text = "-";
            // 
            // lblReserva
            // 
            this.lblReserva.AutoSize = true;
            this.lblReserva.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReserva.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(36)))), ((int)(((byte)(32)))));
            this.lblReserva.Location = new System.Drawing.Point(1298, 474);
            this.lblReserva.Name = "lblReserva";
            this.lblReserva.Size = new System.Drawing.Size(16, 19);
            this.lblReserva.TabIndex = 65;
            this.lblReserva.Text = "-";
            // 
            // errorTxt
            // 
            this.errorTxt.ContainerControl = this;
            // 
            // FormReservacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1481, 808);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cbBus);
            this.Controls.Add(this.lblReserva);
            this.Controls.Add(this.lblBoleto);
            this.Controls.Add(this.lblCosto);
            this.Controls.Add(this.pbBuscar);
            this.Controls.Add(this.btnBoleto);
            this.Controls.Add(this.btnFact);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cbDestinos);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dtReservacion);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCliente);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.grbAsiento);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormReservacion";
            this.Text = "FormReservacion";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormReservacion_FormClosed);
            this.Load += new System.EventHandler(this.FormReservacion_Load);
            this.grbAsiento.ResumeLayout(false);
            this.grbAsiento.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorTxt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnB1;
        private System.Windows.Forms.Button btnA1;
        private System.Windows.Forms.GroupBox grbAsiento;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnD1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnA2;
        private System.Windows.Forms.Button btnB2;
        private System.Windows.Forms.Button btnD4;
        private System.Windows.Forms.Button btnC4;
        private System.Windows.Forms.Button btnB4;
        private System.Windows.Forms.Button btnD3;
        private System.Windows.Forms.Button btnC3;
        private System.Windows.Forms.Button btnA4;
        private System.Windows.Forms.Button btnB3;
        private System.Windows.Forms.Button btnD2;
        private System.Windows.Forms.Button btnC1;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtCliente;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtNombre;
        public System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cb10;
        private System.Windows.Forms.CheckBox cb12;
        private System.Windows.Forms.CheckBox cb09;
        private System.Windows.Forms.CheckBox cb13;
        private System.Windows.Forms.CheckBox cb11;
        private System.Windows.Forms.CheckBox cb08;
        public System.Windows.Forms.DateTimePicker dtReservacion;
        public System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbVuelta;
        private System.Windows.Forms.RadioButton rbIda;
        private System.Windows.Forms.ComboBox cbDestinos;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Button btnFact;
        private System.Windows.Forms.Button btnBoleto;
        private System.Windows.Forms.Button btnA3;
        private System.Windows.Forms.PictureBox pbBuscar;
        public System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Button btnAsiento;
        public System.Windows.Forms.Label lblBoleto;
        public System.Windows.Forms.Label lblReserva;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbBus;
        private System.Windows.Forms.ErrorProvider errorTxt;
    }
}