﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormReservacion : Form
    {
        public FormReservacion()
        {
            InitializeComponent();
        }

        Reservacion reservacion = new Reservacion();
        Cliente c = new Cliente();

        private void btnBoleto_Click(object sender, EventArgs e)
        {
            FormBoleto formBoleto = new FormBoleto();
            formBoleto.ShowDialog();
            btnBoleto.Enabled = false;
        }

        private void btnFact_Click(object sender, EventArgs e)
        {
            FormFactura factura = new FormFactura();
            factura.ShowDialog();
            txtCliente.Clear();
            //txtCliente.Focus();
            txtNombre.Clear();
            rbIda.Checked = false;
            rbVuelta.Checked = false;
            cb08.Checked = false;
            cb09.Checked = false;
            cb10.Checked = false;
            cb11.Checked = false;
            cb12.Checked = false;
            cb13.Checked = false;
            lblBoleto.Text = "-";
            lblReserva.Text = "-";
            lblBoleto.Text = "-";
            btnBoleto.Visible = false;
            btnFact.Visible = false;
            lblCosto.Text = "-";
            btnA1.Enabled = true;
            btnA2.Enabled = true;
            btnA3.Enabled = true;
            btnA4.Enabled = true;
            btnB1.Enabled = true;
            btnB2.Enabled = true;
            btnB3.Enabled = true;
            btnB4.Enabled = true;
            btnC1.Enabled = true;
            btnC2.Enabled = true;
            btnC3.Enabled = true;
            btnC4.Enabled = true;
            btnD1.Enabled = true;
            btnD2.Enabled = true;
            btnD3.Enabled = true;
            btnD4.Enabled = true;
            btnD1.Enabled = true;
            btnD2.Enabled = true;
            btnD3.Enabled = true;
            btnD4.Enabled = true;
            grbAsiento.Enabled = false;
            cb08.Enabled = true;
            cb09.Enabled = true;
            cb10.Enabled = true;
            cb11.Enabled = true;
            cb12.Enabled = true;
            cb13.Enabled = true;
            btnBoleto.Enabled = true;
        }

        private void FormReservacion_Load(object sender, EventArgs e)
        {
            dtReservacion.Value = DateTime.Now;
            reservacion.LlenarItemsCb(cbDestinos);
            reservacion.LlenarItemsCb("exec BusCb", cbBus);
        }

        private void pbBuscar_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                reservacion.Id = txtCliente.Text;
                reservacion.BuscarCliente();
                txtNombre.Text = reservacion.Nombre;
                c.Edad = DateTime.Today.Year - c.Fecha.Year;
            }
        }

        private void btnAsiento_Click(object sender, EventArgs e)
        {
            btnFact.Visible = true;
            btnBoleto.Visible = true;
            
            if (cb08.Checked)
            {
                reservacion.Hora = "08:00";
            }
            else if (cb09.Checked)
            {
                reservacion.Hora = "09:00";
            }
            else if (cb10.Checked)
            {
                reservacion.Hora = "10:00";
            }
            else if (cb11.Checked)
            {
                reservacion.Hora = "11:00";
            }
            else if (cb12.Checked)
            {
                reservacion.Hora = "12:00";
            }
            else 
            {
                reservacion.Hora = "13:00";
            }

            dtReservacion.Value = DateTime.Now;
            reservacion.Fecha = Convert.ToDateTime(dtReservacion.Value.Date);
            
            reservacion.InsertarReservacion();
            reservacion.BuscarAsiento();
            reservacion.InsertarBoleto();
            lblReserva.Text = reservacion.IdReserva.ToString();
            lblBoleto.Text = reservacion.IdBoleto.ToString();
            reservacion.ActualizarAsiento();
            if (rbIda.Checked)
            {
                reservacion.Costo = reservacion.Costo * 1;
                reservacion.Viaje = "Solo ida";
            }
            else
            {
                reservacion.Costo = reservacion.Costo * 2;
                reservacion.Viaje = "Ida y vuelta";
            }
            
            btnAsiento.Enabled = false;
        }

        private void cbBus_SelectedIndexChanged(object sender, EventArgs e)
        {
            grbAsiento.Enabled = true;
            reservacion.Bus = cbBus.SelectedIndex + 1;
            btnAsiento.Enabled = false;

            #region EstadoAsiento
            reservacion.NumAsiento = btnA1.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnA1.BackColor = Color.Red;
                btnA1.Enabled = false;
            }
            else
            {
                btnA1.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnA2.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnA2.BackColor = Color.Red;
                btnA2.Enabled = false;
            }
            else
            {
                btnA2.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnA3.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnA3.BackColor = Color.Red;
                btnA3.Enabled = false;
            }
            else
            {
                btnA3.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnA4.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnA4.BackColor = Color.Red;
                btnA4.Enabled = false;
            }
            else
            {
                btnA4.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnB1.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnB1.BackColor = Color.Red;
                btnB1.Enabled = false;
            }
            else
            {
                btnB1.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnB2.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnB2.BackColor = Color.Red;
                btnB2.Enabled = false;
            }
            else
            {
                btnB2.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnB3.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnB3.BackColor = Color.Red;
                btnB3.Enabled = false;
            }
            else
            {
                btnB3.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnB4.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnB4.BackColor = Color.Red;
                btnB4.Enabled = false;
            }
            else
            {
                btnB4.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnC1.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnC1.BackColor = Color.Red;
                btnC1.Enabled = false;
            }
            else
            {
                btnC1.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnC2.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnC2.BackColor = Color.Red;
                btnC2.Enabled = false;
            }
            else
            {
                btnC2.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnC3.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnC3.BackColor = Color.Red;
                btnC3.Enabled = false;
            }
            else
            {
                btnC3.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnC4.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnC4.BackColor = Color.Red;
                btnC4.Enabled = false;
            }
            else
            {
                btnC4.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnD1.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnD1.BackColor = Color.Red;
                btnD1.Enabled = false;
            }
            else
            {
                btnD1.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnD2.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnD2.BackColor = Color.Red;
                btnD2.Enabled = false;
            }
            else
            {
                btnD2.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnD3.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnD3.BackColor = Color.Red;
                btnD3.Enabled = false;
            }
            else
            {
                btnD3.BackColor = Color.Lime;
            }

            reservacion.NumAsiento = btnD4.Text;
            reservacion.EstadoAsiento();
            if (reservacion.Estado == "Ocupado")
            {
                btnD4.BackColor = Color.Red;
                btnD4.Enabled = false;
            }
            else
            {
                btnD4.BackColor = Color.Lime;
            }
            #endregion
        }

        private void cbDestinos_SelectedIndexChanged(object sender, EventArgs e)
        {
            reservacion.IdDes = cbDestinos.SelectedIndex + 1;
            reservacion.CostoDestino();
            lblCosto.Text = reservacion.Costo.ToString("n2");
        }

        #region ASIENTOS
        private void btnA1_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnA1.Text;
            btnA1.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnA2_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnA2.Text;
            btnA2.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnA3_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnA3.Text;
            btnA3.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnA4_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnA4.Text;
            btnA4.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }
        private void btnB1_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnB1.Text;
            btnB1.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnB2_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnB2.Text;
            btnB2.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnB3_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnB3.Text;
            btnB3.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnB4_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnB4.Text;
            btnB4.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnC2_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnC2.Text;
            btnC2.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnC4_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnC4.Text;
            btnC4.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnC3_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnC3.Text;
            btnC3.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnC1_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnC1.Text;
            btnC1.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnD4_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnD4.Text;
            btnD4.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnD3_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnD3.Text;
            btnD3.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnD2_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnD2.Text;
            btnD2.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        private void btnD1_Click(object sender, EventArgs e)
        {
            btnAsiento.Enabled = true;
            reservacion.IdAsiento = btnD1.Text;
            btnD1.BackColor = Color.Gold;
            btnA1.Enabled = false;
            btnA2.Enabled = false;
            btnA3.Enabled = false;
            btnA4.Enabled = false;
            btnB1.Enabled = false;
            btnB2.Enabled = false;
            btnB3.Enabled = false;
            btnB4.Enabled = false;
            btnC1.Enabled = false;
            btnC2.Enabled = false;
            btnC3.Enabled = false;
            btnC4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
            btnD1.Enabled = false;
            btnD2.Enabled = false;
            btnD3.Enabled = false;
            btnD4.Enabled = false;
        }

        #endregion

        #region HORARIOS
        private void cb08_CheckedChanged(object sender, EventArgs e)
        {
            cb09.Enabled = false;
            cb10.Enabled = false;
            cb11.Enabled = false;
            cb12.Enabled = false;
            cb13.Enabled = false;
        }

        private void cb11_CheckedChanged(object sender, EventArgs e)
        {
            cb08.Enabled = false;
            cb10.Enabled = false;
            cb09.Enabled = false;
            cb12.Enabled = false;
            cb13.Enabled = false;
        }

        private void cb09_CheckedChanged(object sender, EventArgs e)
        {
            cb08.Enabled = false;
            cb10.Enabled = false;
            cb11.Enabled = false;
            cb12.Enabled = false;
            cb13.Enabled = false;
        }

        private void cb12_CheckedChanged(object sender, EventArgs e)
        {
            cb08.Enabled = false;
            cb10.Enabled = false;
            cb11.Enabled = false;
            cb09.Enabled = false;
            cb13.Enabled = false;
        }

        private void cb10_CheckedChanged(object sender, EventArgs e)
        {
            cb08.Enabled = false;
            cb09.Enabled = false;
            cb11.Enabled = false;
            cb12.Enabled = false;
            cb13.Enabled = false;
        }

        private void cb13_CheckedChanged(object sender, EventArgs e)
        {
            cb08.Enabled = false;
            cb10.Enabled = false;
            cb11.Enabled = false;
            cb12.Enabled = false;
            cb09.Enabled = false;
        }
        #endregion

        private void txtCliente_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtCliente.Text) || (txtCliente.Text.Length < txtCliente.MaxLength))
            {
                e.Cancel = true;
                txtCliente.Focus();
                errorTxt.SetError(txtCliente, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtCliente, null);
            }
        }

        private void txtCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void FormReservacion_FormClosed(object sender, FormClosedEventArgs e)
        {
            reservacion.Connection.Close();
        }
    }
}
