﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public class ConecctionSql
    {
        SqlDataAdapter da;
        DataTable dt;

        string conexion = "Data Source = localhost; Initial Catalog = buses;" +
                          "Integrated Security = true";

        public SqlConnection sc = new SqlConnection();

        public ConecctionSql()
        {
            sc.ConnectionString = conexion;
        }

        public void abrir()
        {
            try
            {
                sc.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al abrir la Base de Datos", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void cerrar()
        {
            sc.Close();
        }

        public void CargarDatosdeDestino(DataGridView dgv)
        {
            try
            {
                da = new SqlDataAdapter("Select * from Destinos", conexion);
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
