﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public class Empleado : Persona
    {
        private string direccion;
        private int user;
        private string userName;
        private string userPass;
        private int rol;
        private DateTime fechaC;

        public string Direccion { get => direccion; set => direccion = value; }
        public int User { get => user; set => user = value; }
        public string UserName { get => userName; set => userName = value; }
        public string UserPass { get => userPass; set => userPass = value; }
        public int Rol { get => rol; set => rol = value; }
        public DateTime FechaC { get => fechaC; set => fechaC = value; }

        new public void InsertarPersona()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("InsertarEmpleado", Connection);
            
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@id", Id);
            command.Parameters.AddWithValue("@nombre", Nombre);
            command.Parameters.AddWithValue("@direccion", direccion);
            command.Parameters.AddWithValue("@nac", Fecha);
            command.Parameters.AddWithValue("@con", fechaC);
            command.Parameters.AddWithValue("@tel", Telefono);
            command.Parameters.AddWithValue("@idUser", User);
            command.ExecuteNonQuery();
            Connection.Close();
        }

        public void InsertarUsuario()
        {
            Connection.Open();
            SqlCommand commandUser = new SqlCommand("IngresarUsuario", Connection);

            commandUser.CommandType = CommandType.StoredProcedure;
            commandUser.Parameters.AddWithValue("@name", UserName);
            commandUser.Parameters.AddWithValue("@pass", UserPass);
            commandUser.Parameters.AddWithValue("@rol", Rol);
            commandUser.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;
            commandUser.ExecuteNonQuery();
            user = Convert.ToInt32(commandUser.Parameters["@id"].Value.ToString());
            Connection.Close();
        }

        public void LlenarItemsCb(string comando, ComboBox cb)
        {
            Connection.Open();
            //connection.Open();
            SqlCommand command = new SqlCommand(comando, Connection);
            SqlDataReader readerCb = command.ExecuteReader();

            while (readerCb.Read())
            {
                cb.Items.Add(readerCb["Rol"].ToString());
            }

            readerCb.Close();

            Connection.Close();
        }

        new public void CargaDatos(string comando, DataGridView dgv)
        {
            Connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(comando, Connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgv.DataSource = table;
            Connection.Close();
        }

    }
}
