﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoFinal
{
    public class Factura : Reservacion
    {
        private DateTime fechaFact;
        private int numF;
        private double total;
        private double subTotal;
        private double desc;
        private double isv;

        public double Total { get => total; set => total = value; }
        public double SubTotal { get => subTotal; set => subTotal = value; }
        public double Desc { get => desc; set => desc = value; }
        public double Isv { get => isv; set => isv = value; }
        public DateTime FechaFact { get => fechaFact; set => fechaFact = value; }
        public int NumF { get => numF; set => numF = value; }

        public void IngresarFact()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("InsertarFact", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@fecha", fechaFact);
            command.Parameters.Add("@idFact", SqlDbType.Int).Direction = ParameterDirection.Output;
            command.ExecuteNonQuery();
            numF = Convert.ToInt32(command.Parameters["@idFact"].Value.ToString());
            Connection.Close();
        }

        public void IngresarDetalleFact()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("InsertarDetalle", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@fact", numF);
            command.Parameters.AddWithValue("@boleto", IdBoleto);
            command.Parameters.AddWithValue("@viaje", Viaje);
            command.ExecuteNonQuery();
            Connection.Close();
        }

        public void CalcularFact()
        {
            Cliente c = new Cliente();
            subTotal = Costo;
            if(c.Edad < 60)
            {
                desc = 0;
            }
            else
            {
                desc = subTotal * 0.25;
            }
            isv = (subTotal - desc) * 0.15;
            total = subTotal - desc + isv;
        }
    }
}
