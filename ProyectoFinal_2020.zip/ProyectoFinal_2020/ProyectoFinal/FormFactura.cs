﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormFactura : Form
    {
        public FormFactura()
        {
            InitializeComponent();
        }

        Factura fact = new Factura();

        private void FormFactura_Load(object sender, EventArgs e)
        {
            dtpFact.Value = DateTime.Now;
        }

        private void btnFactura_Click(object sender, EventArgs e)
        {
            fact.FechaFact = Convert.ToDateTime(dtpFact.Value.Date);
            fact.IngresarFact();
            fact.IngresarDetalleFact();
            fact.CalcularFact();
            dtpFact.Visible = false;

            // TODO: This line of code loads data into the 'busesDataSet.ImprimirDet' table. You can move, or remove it, as needed.
            this.ImprimirDetTableAdapter.Fill(this.busesDataSet.ImprimirDet);
            // TODO: This line of code loads data into the 'busesDataSet.ImprimirReservacion' table. You can move, or remove it, as needed.
            this.ImprimirReservacionTableAdapter.Fill(this.busesDataSet.ImprimirReservacion);
            // TODO: This line of code loads data into the 'busesDataSet.ImprimirFact' table. You can move, or remove it, as needed.
            this.ImprimirFactTableAdapter.Fill(this.busesDataSet.ImprimirFact);

            this.reportViewer1.RefreshReport();

            btnFactura.Visible = false;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = false;
            label4.Visible = true;
            lblS.Visible = true;
            lblDesc.Visible = true;
            lblSub.Visible = true;
            lblIsv.Visible = true;
            lblTotal.Visible = true;
            btnOk.Visible = true;

            lblSub.Text = "L. " + fact.SubTotal.ToString("n2");
            lblDesc.Text = "L. " + fact.Desc.ToString("n2");
            lblIsv.Text = "L. " + fact.Isv.ToString("n2");
            lblTotal.Text = "L. " + fact.Total.ToString("n2");
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
