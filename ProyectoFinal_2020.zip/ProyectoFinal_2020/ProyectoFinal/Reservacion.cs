﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public class Reservacion 
    {
        private SqlConnection connection = new SqlConnection("Data Source=localhost;Initial Catalog=buses;Integrated Security=True");
        private static string nombre;
        private static string id; 
        private static DateTime fecha;
        private static string hora;
        private static int idDes;
        protected static int idReserva; 
        private static string idAsiento;
        protected static int idBoleto; 
        private static string estado;
        private static string numAsiento;
        protected static double costo; 
        protected static string viaje;
        private static int bus;
        private static int asi;

        public SqlConnection Connection { get => connection; set => connection = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Id { get => id; set => id = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public string Hora { get => hora; set => hora = value; }
        public int IdDes { get => idDes; set => idDes = value; }
        public int IdReserva { get => idReserva; set => idReserva = value; }
        public string IdAsiento { get => idAsiento; set => idAsiento = value; }
        public int IdBoleto { get => idBoleto; set => idBoleto = value; }
        public string Estado { get => estado; set => estado = value; }
        public string NumAsiento { get => numAsiento; set => numAsiento = value; }
        public double Costo { get => costo; set => costo = value; }
        public int Bus { get => bus; set => bus = value; }
        public int Asi { get => asi; set => asi = value; }
        public string Viaje { get => viaje; set => viaje = value; }

        public string BuscarCliente()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("BuscarCliente", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@idCliente", id);
            SqlDataReader reader = command.ExecuteReader();

            if (!reader.Read())
            {
                MessageBox.Show("Registro no encontrado", "BIG BUS TOUR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                nombre = reader["Nombre"].ToString();
            }

            reader.Close();
            Connection.Close();
            return nombre;
        }

        public void LlenarItemsCb(ComboBox cb)
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("exec DestinosCb", Connection);
            SqlDataReader readerCb = command.ExecuteReader();

            while (readerCb.Read())
            {
                cb.Items.Add(readerCb["Nombre"].ToString());
            }

            readerCb.Close();

            Connection.Close();
        }

        public void InsertarReservacion()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("IngresarReservacion", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@hora", hora);
            command.Parameters.AddWithValue("@fecha", fecha);
            command.Parameters.AddWithValue("@idCliente", id);
            command.Parameters.AddWithValue("@idDestino", IdDes);
            command.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;
            command.ExecuteNonQuery();
            idReserva = Convert.ToInt32(command.Parameters["@id"].Value.ToString());
            Connection.Close();
        }

        public void InsertarBoleto()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("IngresarBoleto", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@idAsiento", asi);
            command.Parameters.AddWithValue("@idRes", idReserva);
            command.Parameters.Add("@idBoleto", SqlDbType.Int).Direction = ParameterDirection.Output;
            command.ExecuteNonQuery();
            idBoleto = Convert.ToInt32(command.Parameters["@idBoleto"].Value.ToString());
            Connection.Close();
        }

        public void ActualizarAsiento()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("EstadoAsiento", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@idAsiento", IdAsiento);
            command.Parameters.AddWithValue("@estado", "Ocupado");
            command.Parameters.AddWithValue("@bus", Bus);
            command.ExecuteNonQuery();
            
            Connection.Close();
        }

        public string EstadoAsiento()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("BuscarAsiento", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@id",numAsiento); 
            command.Parameters.AddWithValue("@bus", bus);

            SqlDataReader readerEA = command.ExecuteReader();

            if (!readerEA.Read())
            {
                MessageBox.Show("Registro no encontrado", "BIG BUS TOUR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                estado = readerEA["Estado"].ToString();
            }

            readerEA.Close();
            Connection.Close();
            
            return estado;
        }

        public void LlenarItemsCb(string comando, ComboBox cb) 
        {
            Connection.Open();
            SqlCommand command = new SqlCommand(comando, Connection);
            SqlDataReader readerCb = command.ExecuteReader();

            while (readerCb.Read())
            {
                cb.Items.Add(readerCb["placa"].ToString());
                
            }

            readerCb.Close();

            Connection.Close();
        }

        public string BuscarAsiento()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("BuscarAsientoCodigo", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@id", idAsiento);
            command.ExecuteNonQuery();
            SqlDataReader reader = command.ExecuteReader();

            if (!reader.Read())
            {
                MessageBox.Show("Registro no encontrado", "BIG BUS TOUR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                asi = Convert.ToInt32(reader["id_asiento"].ToString());
            }

            reader.Close();
            Connection.Close();
            return nombre;
        }

        public double CostoDestino()
        {

            
            Connection.Open();
            SqlCommand command = new SqlCommand("CostoDestino", Connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@idDes", idDes);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                costo = Convert.ToDouble(reader["Costo"].ToString());

            }

            reader.Close();
            Connection.Close();

            return costo;
        }
    }
}
