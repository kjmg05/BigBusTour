﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormEmpleado : Form
    {
        public FormEmpleado()
        {
            InitializeComponent();
        }
        Empleado empleado = new Empleado();

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                empleado.Id = txtId.Text;
                empleado.Nombre = txtNombre.Text;
                empleado.Direccion = txtDir.Text;
                empleado.Telefono = txtTel.Text;
                empleado.Fecha = Convert.ToDateTime(dtNac.Value.Date);
                empleado.FechaC = Convert.ToDateTime(dtCon.Value.Date);
                gbUsuario.Enabled = true;
                btnGuardar.Enabled = false;
                empleado.LlenarItemsCb("exec ComboBox", cbRol);
            } 
        }

        private void FormEmpleado_Load(object sender, EventArgs e)
        {
            dtCon.Value = DateTime.Now;
            empleado.CargaDatos("exec CargaEmpleado", dgvEmpleado);
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            empleado.UserName = txtUser.Text;
            empleado.UserPass = txtPass.Text;
            empleado.Rol = cbRol.SelectedIndex + 1;
            empleado.InsertarUsuario();
            empleado.InsertarPersona();
            btnGuardar.Enabled = true;
            dtNac.MaxDate = DateTime.Now.AddYears(18);
            dtCon.MinDate = DateTime.Now;
            empleado.CargaDatos("exec CargaEmpleado", dgvEmpleado);
            txtDir.Clear();
            txtId.Clear();
            txtNombre.Clear();
            txtPass.Clear();
            txtTel.Clear();
            txtUser.Clear();
        }

        private void FormEmpleado_FormClosed(object sender, FormClosedEventArgs e)
        {
            empleado.Connection.Close();
        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || (txtId.Text.Length < txtId.MaxLength))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtDir_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetter(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtTel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) || (txtTel.Text.Length < txtTel.MaxLength))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        private void txtId_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                e.Cancel = true;
                txtId.Focus();
                errorTxt.SetError(txtId, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtId, null);
            }
        }

        private void txtDir_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtDir.Text))
            {
                e.Cancel = true;
                txtDir.Focus();
                errorTxt.SetError(txtDir, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtDir, null);
            }
        }

        private void txtNombre_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNombre.Text))
            {
                e.Cancel = true;
                txtNombre.Focus();
                errorTxt.SetError(txtNombre, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtNombre, null);
            }
        }

        private void txtTel_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtTel.Text))
            {
                e.Cancel = true;
                txtTel.Focus();
                errorTxt.SetError(txtTel, "Por favor, complete los campos requeridos");
            }
            else
            {
                e.Cancel = false;
                errorTxt.SetError(txtTel, null);
            }
        }
    }
}
