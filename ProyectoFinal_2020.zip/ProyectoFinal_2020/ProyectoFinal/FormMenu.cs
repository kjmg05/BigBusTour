﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public partial class FormMenu : Form
    {
        #region Metodo para abrir Formulario
        //METODO PARA ABRIR UN FORMULARIO DENTRO DEL PANEL
        private void AbrirFormulario<MiForm>() where MiForm : Form, new()
        {
            Form formulario;
            formulario = panelFormularios.Controls.OfType<MiForm>().FirstOrDefault(); //Busca en la coleccion el formulario
            //No existe
            if (formulario == null)
            {
                formulario = new MiForm();
                formulario.TopLevel = false;
                formulario.FormBorderStyle = FormBorderStyle.None;
                formulario.Dock = DockStyle.Fill;
                panelFormularios.Controls.Add(formulario);
                panelFormularios.Tag = formulario;
                formulario.Show();
                formulario.BringToFront();
            }
            //existe
            else
            {
                formulario.BringToFront();
            }
        }
        #endregion

        public FormMenu(string nombre)
        {
            InitializeComponent();
            lblUsuario.Text = nombre;
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pbCerrar_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Está seguro que desea cerrar la aplicación", "BIG BUS TOUR", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if(result == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void pbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnBus_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormBus>();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormCliente>();
        }

        private void btnReservacion_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormReservacion>();
        }

        private void btnFactura_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormEmpleado>();
        }

        private void btnDash_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormDash>();
        }

        private void btnDestino_Click(object sender, EventArgs e)
        {
            AbrirFormulario<FormDestinos>();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Está seguro que desea cerrar sesión", "BIG BUS TOUR", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                this.Close();
                FormInicioSesion inicioSesion = new FormInicioSesion();
                inicioSesion.Show();
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            lblFecha.Text = DateTime.Now.ToShortDateString();
            lblHora.Text = DateTime.Now.ToShortTimeString();
        }
    }
}
