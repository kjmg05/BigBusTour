﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ProyectoFinal
{
    public class AutoBus
    {
        private static string placa;
        private string modelo;
        private static int capacidad;
        private SqlConnection connection = new SqlConnection("Data Source=localhost;Initial Catalog=buses;Integrated Security=True");
        private static double costoDestino;
        private static string destino;
        private static int busId;
        private static string num;
        private static string estado;

        public string Placa { get => placa; set => placa = value; }
        public string Modelo { get => modelo; set => modelo = value; }
        public int Capacidad { get => capacidad; set => capacidad = value; }
        public SqlConnection Connection { get => connection; set => connection = value; }
        public  double CostoDestino { get => costoDestino; set => costoDestino = value; }
        public string Destino { get => destino; set => destino = value; }
        public int BusId { get => busId; set => busId = value; }
        public string Num { get => num; set => num = value; }
        public string Estado { get => estado; set => estado = value; }

        public void InsertarBus()
        {
            Connection.Open();
            SqlCommand command = new SqlCommand("InsertarBus", Connection);

            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@placa", placa);
            command.Parameters.AddWithValue("@modelo", modelo);
            command.Parameters.AddWithValue("@num", capacidad);
            command.Parameters.Add("@id", SqlDbType.Int).Direction = ParameterDirection.Output;
            command.ExecuteNonQuery();
            busId = Convert.ToInt32(command.Parameters["@id"].Value.ToString());
            Connection.Close();
        }

        public void InsertarAsiento()
        {
            Connection.Open();
            SqlCommand commandA = new SqlCommand("InsertarAsiento", Connection);

            commandA.CommandType = CommandType.StoredProcedure;
            commandA.Parameters.AddWithValue("@num", num);
            commandA.Parameters.AddWithValue("@estado", Estado);
            commandA.Parameters.AddWithValue("@id", BusId);
            commandA.ExecuteNonQuery();
            Connection.Close();
        }

        public void CargaDatos(string comando, DataGridView dgv)
        {
            Connection.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(comando, Connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dgv.DataSource = table;
            Connection.Close();
        }

        public void ActualizarBus(int i, string placa, string modelo)
        {
            Connection.Open();
            SqlCommand commandA = new SqlCommand("ActualizarBus", Connection);

            commandA.CommandType = CommandType.StoredProcedure;
            commandA.Parameters.AddWithValue("@idBus", i);
            commandA.Parameters.AddWithValue("@placa", placa);
            commandA.Parameters.AddWithValue("@mod", modelo);
            commandA.Parameters.AddWithValue("@c", capacidad);
            commandA.ExecuteNonQuery();
            Connection.Close();
        }

        public void EliminarBus(string comando, int i)
        {
            Connection.Open();
            SqlCommand commandE = new SqlCommand(comando, Connection);

            commandE.CommandType = CommandType.StoredProcedure;
            commandE.Parameters.AddWithValue("@idBus", i);
            commandE.ExecuteNonQuery();
            Connection.Close();
        }

        public void EliminarAsiento(int i)
        {
            Connection.Open();
            SqlCommand commandB = new SqlCommand("EliminarAsiento", Connection);

            commandB.CommandType = CommandType.StoredProcedure;
            commandB.Parameters.AddWithValue("@idBus", 3);
            commandB.ExecuteNonQuery();
            Connection.Close();
        }
    }
}
