﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;        
using System.Data;                  
using System.Windows.Forms;        

namespace ProyectoFinal
{
    public class ConecctionSql1
    {
        SqlDataAdapter da;  
        DataTable dt;       

        String conexion = "Data Source=localhost; Initial Catalog=buses  ;" + "Integrated Security=True";

        public SqlConnection sc = new SqlConnection();

        public ConecctionSql1()
        {
            sc.ConnectionString = conexion;
        }

        public void Abrir()
        {
            sc.Open();
        }

        public void Cerrar()
        {
            sc.Close();

        }

        public void CargarDatosCliente(DataGridView dgv)
        {
            try
            {
                da = new SqlDataAdapter("select * from clientes", conexion);
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("¡LO SENTIMOS, ERROR AL CARGAR LOS DATOS!", "ERROR", MessageBoxButtons.OK);

            }
        }
    }
}
